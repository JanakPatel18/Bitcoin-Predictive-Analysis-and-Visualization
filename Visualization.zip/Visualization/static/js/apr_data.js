 var data = [
  {
    Date: "04/01/21",
     Weighted_Price : "",
    Forecast: "$61,519.78"
  },
  {
    Date: "04/02/21",
     Weighted_Price : "",
    Forecast: "$59,958.74"
  },
  {
    Date: "04/03/21",
     Weighted_Price : "",
    Forecast: "$57,997.02"
  },
  {
    Date: "04/04/21",
     Weighted_Price : "",
    Forecast: "$59,311.69"
  },
  {
    Date: "04/05/21",
     Weighted_Price : "",
    Forecast: "$59,668.55"
  },
  {
    Date: "04/06/21",
     Weighted_Price : "",
    Forecast: "$60,351.60"
  },
  {
    Date: "04/07/21",
     Weighted_Price : "",
    Forecast: "$61,097.00"
  },
  {
    Date: "04/08/21",
     Weighted_Price : "",
    Forecast: "$60,350.91"
  },
  {
    Date: "04/09/21",
     Weighted_Price : "",
    Forecast: "$60,924.33"
  },
  {
    Date: "04/10/21",
     Weighted_Price : "",
    Forecast: "$61,360.38"
  },
  {
    Date: "04/11/21",
     Weighted_Price : "",
    Forecast: "$61,883.19"
  },
  {
    Date: "04/12/21",
     Weighted_Price : "",
    Forecast: "$62,320.73"
  },
  {
    Date: "04/13/21",
     Weighted_Price : "",
    Forecast: "$61,813.51"
  },
  {
    Date: "04/14/21",
     Weighted_Price : "",
    Forecast: "$62,808.03"
  },
  {
    Date: "04/15/21",
     Weighted_Price : "",
    Forecast: "$64,609.07"
  }
]